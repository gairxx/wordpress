ZASS WORDPRESS THEME README

== BRIEF INFORMATION ==

Theme URI: 	http://zass.althemist.com
Author: 	theAlthemist
Author URI: http://themeforest.net/user/theAlThemist
License: 	Themeforest Split Licence


== DESCRIPTION ==

Zass Theme is a modern and powerful WordPress / WooCommerce theme, suitable for both portfolio and online shopping websites, built by e-commerce profesionals for e-commerce professionals.
The main goal behind creating the Zass theme was to offer a sophisticated e-commerce platform, following the latest tendencies in web design.
Despite the modern and complex structure, the theme is clean and light by nature so it's suitable for any type of e-commerce business and prove that
WordPress could be used not only for small stores but also as a fully professional e-commerce site solution.

== SUPPORT ==

http://althemist.com/support/

== DOCUMENTATION ==

http://althemist.com/docs/zass